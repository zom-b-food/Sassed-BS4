<script src="../assets-bs/js/components/popper.min.js" type="text/javascript"></script>
<script src="../assets-bs/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets-bs/js/bootstrap-switch.js" type="text/javascript"></script>
<script src="../assets-bs/js/components/accordion.js" type="text/javascript"></script>
<script src="../assets-bs/js/components/nouislider.min.js" type="text/javascript"></script>
<script src="../assets-bs/js/components/wow.min.js" type="text/javascript"></script>
<script src="../assets-bs/js/components/jquery.filtertable.js" type="text/javascript"></script>
<script src="../assets-bs/js/components/tablesort.js" type="text/javascript"></script>
<script src="../assets-bs/js/components/jquery.beefup.min.js"></script>
